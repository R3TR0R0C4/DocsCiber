# Vtiger Vulnerable Extension

An installable Vtiger extension which provides interface to perform command execution on the respective web server.

/index.php?module=VtigerVulnPlugin&action=Gateway&cmd=id

### Steps to use

1. Create a zip archive including all the files in the repository
2. Install the zip via Settings -> Module Manager
3. Ready to cook..

Don't use it in a production environment.
